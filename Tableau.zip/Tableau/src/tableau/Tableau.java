/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableau;

/**
 *
 * @author mehdi
 */
public class Tableau {

    public static void main(String[] args) {

//----------------------------------------------------------------------------//  
//        String tabLogin[] = {"toto", "titi", "tata"};
//        String tabPassword[] = {"123", "456", "789"};
//        System.out.println("Le mot de pass de " + tabLogin[0] + " est " + tabPassword[0]);
//        System.out.println("Le mot de pass de " + tabLogin[1] + " est " + tabPassword[1]);
//        System.out.println("Le mot de pass de " + tabLogin[2] + " est " + tabPassword[2]);
//
//    }
//----------------------------------------------------------------------------//
//        for (String tabLogin1 : tabLogin) {
//            System.out.println(tabLogin1);
//        }
//        
//
//        for (String tabPassword1 : tabPassword) {
//            System.out.println(tabPassword1);
//        }
//----------------------------------------------------------------------------//

        String tabLogin[] = {"toto", "titi", "tata"};
        String tabPassword[] = {"123", "456", "789"};

        for (int i = 0; i < tabLogin.length; i++) {
            System.out.println(tabLogin[i] + " " + tabPassword[i]);
        }
    }
}
