/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exojava2;

/**
 *
 * @author mehdi
 */
public class Compte {
       String id;
    String login;
    int password;

    public Compte(String id, String login, int password) {

        this.id = id;
        this.login = login;
        this.password = password;
    }

    @Override
    public String toString() {
        return "Compte{" + "id=" + id + ", login=" + login + ", password=" + password + '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }

}
